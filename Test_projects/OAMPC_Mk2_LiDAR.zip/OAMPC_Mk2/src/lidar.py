"""QLabs LiDAR reading and distance filtering for QCar2 OAMPC Mk2."""

from __future__ import annotations

from typing import Any

import numpy as np


DEFAULT_SAMPLE_POINTS = 720
MIN_VALID_DISTANCE = 0.2
MAX_VALID_DISTANCE = 12.0


# Convert a raw LiDAR response into a filtered nearest-distance dictionary.
def process_lidar_response(status: bool, angles: Any, distances: Any) -> dict[str, Any]:
    if not status or distances is None:
        return {"status": "no_valid_distance", "nearest_obstacle_distance": None, "angles": np.array([]), "distances": np.array([])}

    angle_array = np.asarray(angles if angles is not None else [], dtype=float).squeeze()
    distance_array = np.asarray(distances, dtype=float).squeeze()
    if distance_array.size == 0:
        return {"status": "no_valid_distance", "nearest_obstacle_distance": None, "angles": angle_array, "distances": distance_array}

    finite_mask = np.isfinite(distance_array)
    range_mask = (distance_array >= MIN_VALID_DISTANCE) & (distance_array <= MAX_VALID_DISTANCE)
    valid_mask = finite_mask & range_mask
    valid_distances = distance_array[valid_mask]

    if valid_distances.size == 0:
        return {"status": "no_valid_distance", "nearest_obstacle_distance": None, "angles": angle_array, "distances": distance_array}

    return {
        "status": "ok",
        "nearest_obstacle_distance": float(np.min(valid_distances)),
        "angles": angle_array,
        "distances": distance_array,
    }


# Read the QLabs QCar2 LiDAR and return the nearest valid obstacle distance.
def read_qlabs_lidar(qcar2: Any, sample_points: int = DEFAULT_SAMPLE_POINTS) -> dict[str, Any]:
    try:
        status, angles, distances = qcar2.get_lidar(samplePoints=int(sample_points))
    except Exception as exc:
        return {"status": f"exception: {exc}", "nearest_obstacle_distance": None, "angles": np.array([]), "distances": np.array([])}
    return process_lidar_response(bool(status), angles, distances)
