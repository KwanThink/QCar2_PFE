"""Obstacle geometry and relevance helpers for QCar2 OAMPC Mk2."""

from __future__ import annotations

import math
from typing import Any

import numpy as np


SUPPORTED_OBSTACLE_TYPES = {"cube", "cone", "cylinder", "sphere"}
ROUND_FOOTPRINT_EDGES = 12
GEOMETRY_EPSILON = 1.0e-9


# Return a two-dimensional rotation matrix for a yaw angle in radians.
def rotation_matrix_2d(yaw: float) -> np.ndarray:
    cosine = math.cos(float(yaw))
    sine = math.sin(float(yaw))
    return np.array([[cosine, -sine], [sine, cosine]], dtype=float)


# Return the signed polygon area for ordered vertices.
def polygon_signed_area(vertices: np.ndarray) -> float:
    x_coordinates = vertices[:, 0]
    y_coordinates = vertices[:, 1]
    return float(0.5 * np.sum(x_coordinates * np.roll(y_coordinates, -1) - y_coordinates * np.roll(x_coordinates, -1)))


# Ensure polygon vertices are ordered counter-clockwise.
def ensure_counter_clockwise(vertices: np.ndarray) -> np.ndarray:
    ordered_vertices = np.asarray(vertices, dtype=float).reshape((-1, 2))
    if polygon_signed_area(ordered_vertices) < 0.0:
        ordered_vertices = ordered_vertices[::-1].copy()
    return ordered_vertices


# Build a rectangle footprint from center, full size, and yaw.
def rectangle_vertices(center: np.ndarray, size: np.ndarray, yaw: float) -> np.ndarray:
    half_x = 0.5 * float(size[0])
    half_y = 0.5 * float(size[1])
    local_vertices = np.array(
        [
            [-half_x, -half_y],
            [half_x, -half_y],
            [half_x, half_y],
            [-half_x, half_y],
        ],
        dtype=float,
    )
    return ensure_counter_clockwise(center.reshape(1, 2) + local_vertices @ rotation_matrix_2d(yaw).T)


# Build a regular polygon footprint for round QLabs shapes.
def regular_polygon_vertices(center: np.ndarray, scale: np.ndarray, yaw: float, number_of_edges: int = ROUND_FOOTPRINT_EDGES) -> np.ndarray:
    radius = 0.5 * max(float(scale[0]), float(scale[1]))
    angles = np.linspace(0.0, 2.0 * math.pi, int(number_of_edges), endpoint=False) + float(yaw)
    vertices = np.column_stack((center[0] + radius * np.cos(angles), center[1] + radius * np.sin(angles)))
    return ensure_counter_clockwise(vertices)


# Convert ordered convex polygon vertices into G p <= f half-spaces.
def polygon_to_halfspaces(vertices: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    polygon_vertices = ensure_counter_clockwise(vertices)
    centroid = np.mean(polygon_vertices, axis=0)
    normal_rows: list[np.ndarray] = []
    right_hand_side: list[float] = []

    for edge_index in range(len(polygon_vertices)):
        first_point = polygon_vertices[edge_index]
        second_point = polygon_vertices[(edge_index + 1) % len(polygon_vertices)]
        tangent = second_point - first_point
        edge_length = float(np.linalg.norm(tangent))
        if edge_length <= GEOMETRY_EPSILON:
            continue
        normal = np.array([tangent[1], -tangent[0]], dtype=float) / edge_length
        face_bound = float(np.dot(normal, first_point))
        if float(np.dot(normal, centroid)) > face_bound:
            normal = -normal
            face_bound = -face_bound
        normal_rows.append(normal)
        right_hand_side.append(face_bound)

    if not normal_rows:
        raise ValueError("Obstacle polygon does not contain a valid edge.")
    return np.vstack(normal_rows), np.asarray(right_hand_side, dtype=float)


# Normalize one obstacle dictionary and choose a cube fallback for invalid types.
def normalize_obstacle_config(raw_obstacle: dict[str, Any], obstacle_id: int) -> dict[str, Any]:
    obstacle_type = str(raw_obstacle.get("type", "cube")).lower()
    if obstacle_type not in SUPPORTED_OBSTACLE_TYPES:
        print(f"Warning: obstacle {obstacle_id} uses unsupported type '{obstacle_type}', falling back to cube.")
        obstacle_type = "cube"
    return {
        "obstacle_id": int(obstacle_id),
        "type": obstacle_type,
        "loc": [float(value) for value in raw_obstacle.get("loc", [0.0, 0.0, 0.0])],
        "rot": [float(value) for value in raw_obstacle.get("rot", [0.0, 0.0, 0.0])],
        "scale": [float(value) for value in raw_obstacle.get("scale", [0.0, 0.0, 0.0])],
        "color": [float(value) for value in raw_obstacle.get("color", [0.0, 1.0, 0.0])],
    }


# Build a complete obstacle geometry record from one normalized obstacle config.
def build_obstacle(raw_obstacle: dict[str, Any], obstacle_id: int) -> dict[str, Any]:
    normalized = normalize_obstacle_config(raw_obstacle, obstacle_id)
    center = np.asarray(normalized["loc"][:2], dtype=float)
    scale = np.asarray(normalized["scale"][:2], dtype=float)
    yaw = float(normalized["rot"][2])

    if normalized["type"] == "cube":
        vertices = rectangle_vertices(center, scale, yaw)
    else:
        # QLabs BasicShape scale is used here as the full 2D footprint size for consistency with spawn().
        vertices = regular_polygon_vertices(center, scale, yaw, ROUND_FOOTPRINT_EDGES)

    halfspace_matrix, halfspace_vector = polygon_to_halfspaces(vertices)
    normalized.update(
        {
            "center": center,
            "vertices": vertices,
            "G": halfspace_matrix,
            "f": halfspace_vector,
            "number_of_edges": int(len(halfspace_vector)),
            "active": False,
        }
    )
    return normalized


# Build all obstacle geometry records from the Mk2 YAML config.
def build_obstacle_list(config: dict[str, Any]) -> list[dict[str, Any]]:
    obstacle_config = config["obstacle_avoidance"]
    if not bool(obstacle_config["enabled"]):
        return []
    raw_obstacles = obstacle_config["obstacles"] or []
    return [build_obstacle(raw_obstacle, obstacle_id) for obstacle_id, raw_obstacle in enumerate(raw_obstacles)]


# Return true if a point is inside the obstacle inflated by a scalar margin.
def point_inside_inflated_obstacle(point: np.ndarray, obstacle: dict[str, Any], margin: float) -> bool:
    point_array = np.asarray(point, dtype=float).reshape(2)
    halfspace_matrix = np.asarray(obstacle["G"], dtype=float)
    halfspace_vector = np.asarray(obstacle["f"], dtype=float)
    return bool(np.all(halfspace_matrix @ point_array <= halfspace_vector + float(margin)))


# Return the distance between a point and a finite line segment.
def point_to_segment_distance(point: np.ndarray, first_point: np.ndarray, second_point: np.ndarray) -> float:
    point_array = np.asarray(point, dtype=float)
    start = np.asarray(first_point, dtype=float)
    end = np.asarray(second_point, dtype=float)
    segment = end - start
    squared_length = float(np.dot(segment, segment))
    if squared_length <= GEOMETRY_EPSILON:
        return float(np.linalg.norm(point_array - start))
    ratio = float(np.clip(np.dot(point_array - start, segment) / squared_length, 0.0, 1.0))
    projection = start + ratio * segment
    return float(np.linalg.norm(point_array - projection))


# Return the approximate surface distance from a point to an obstacle polygon.
def distance_to_obstacle_surface(point: np.ndarray, obstacle: dict[str, Any]) -> float:
    point_array = np.asarray(point, dtype=float).reshape(2)
    if point_inside_inflated_obstacle(point_array, obstacle, 0.0):
        return 0.0
    vertices = np.asarray(obstacle["vertices"], dtype=float)
    distances = [point_to_segment_distance(point_array, vertices[index], vertices[(index + 1) % len(vertices)]) for index in range(len(vertices))]
    return float(min(distances)) if distances else float("inf")


# Return true if any trajectory point is inside or close to an obstacle.
def trajectory_intersects_inflated_obstacle(points: np.ndarray, obstacle: dict[str, Any], margin: float) -> bool:
    point_array = np.asarray(points, dtype=float)
    if point_array.size == 0:
        return False
    for point in point_array.reshape((-1, 2)):
        if point_inside_inflated_obstacle(point, obstacle, margin):
            return True
    return False


# Return true if sampled segments cross the inflated obstacle footprint.
def segments_intersect_inflated_obstacle(points: np.ndarray, obstacle: dict[str, Any], margin: float) -> bool:
    point_array = np.asarray(points, dtype=float).reshape((-1, 2))
    if len(point_array) < 2:
        return False
    for index in range(len(point_array) - 1):
        start = point_array[index]
        end = point_array[index + 1]
        for ratio in np.linspace(0.0, 1.0, 7):
            sample = (1.0 - ratio) * start + ratio * end
            if point_inside_inflated_obstacle(sample, obstacle, margin):
                return True
    return False


# Return the reference direction using the horizon first and the measured heading as fallback.
def reference_direction(reference_positions: np.ndarray, current_state: np.ndarray) -> np.ndarray:
    positions = np.asarray(reference_positions, dtype=float).reshape((-1, 2))
    if len(positions) >= 2:
        direction = positions[min(1, len(positions) - 1)] - positions[0]
        norm_value = float(np.linalg.norm(direction))
        if norm_value > GEOMETRY_EPSILON:
            return direction / norm_value
    yaw = float(current_state[2])
    return np.array([math.cos(yaw), math.sin(yaw)], dtype=float)


# Return true if the obstacle center lies ahead of the current vehicle position.
def obstacle_is_ahead(current_state: np.ndarray, reference_positions: np.ndarray, obstacle: dict[str, Any], margin: float) -> bool:
    current_position = np.asarray(current_state[:2], dtype=float)
    direction = reference_direction(reference_positions, current_state)
    relative_center = np.asarray(obstacle["center"], dtype=float) - current_position
    longitudinal_distance = float(np.dot(relative_center, direction))
    if longitudinal_distance <= 0.0:
        return False
    lateral_distance = abs(float(np.cross(direction, relative_center)))
    distance_limit = max(float(margin) + 0.5, 0.75 * float(np.linalg.norm(relative_center)))
    return bool(lateral_distance <= distance_limit)


# Return true if the nearest LiDAR distance is within the configured activation range.
def lidar_gate_accepts_obstacle(nearest_obstacle_distance: float | None, active_distance: float) -> bool:
    if nearest_obstacle_distance is None or not np.isfinite(nearest_obstacle_distance):
        return False
    lidar_distance = float(nearest_obstacle_distance)
    if lidar_distance < 0.2 or lidar_distance > 12.0:
        return False
    return bool(lidar_distance <= float(active_distance))


# Extract Cartesian positions from a flat-state reference horizon.
def reference_positions_from_state_horizon(reference_state: np.ndarray) -> np.ndarray:
    reference_array = np.asarray(reference_state, dtype=float)
    return np.column_stack((reference_array[0, :], reference_array[1, :]))


# Select obstacles whose predicted ego trajectory collides with their inflated footprint.
def select_predicted_collision_obstacles(
    obstacles: list[dict[str, Any]],
    predicted_positions: np.ndarray,
    gamma: float,
) -> list[dict[str, Any]]:
    active_obstacles: list[dict[str, Any]] = []
    if not obstacles:
        return active_obstacles

    predicted_points = np.asarray(predicted_positions, dtype=float).reshape((-1, 2))
    for obstacle in obstacles:
        point_collision = trajectory_intersects_inflated_obstacle(predicted_points, obstacle, gamma)
        segment_collision = segments_intersect_inflated_obstacle(predicted_points, obstacle, gamma)
        obstacle_copy = dict(obstacle)
        obstacle_copy["active"] = bool(point_collision or segment_collision)
        obstacle_copy["relevance_debug"] = {
            "predicted_points": bool(point_collision),
            "predicted_segments": bool(segment_collision),
        }
        if obstacle_copy["active"]:
            active_obstacles.append(obstacle_copy)
    return active_obstacles


# Select obstacles for the MIQP by checking predicted collision over the MPC horizon.
def select_active_obstacles(
    obstacles: list[dict[str, Any]],
    nominal_positions: np.ndarray,
    reference_state: np.ndarray,
    current_state: np.ndarray,
    nearest_obstacle_distance: float | None,
    gamma: float,
    active_distance: float,
) -> list[dict[str, Any]]:
    active_obstacles: list[dict[str, Any]] = []
    if not obstacles:
        return active_obstacles

    # The LiDAR distance is kept only for logging/diagnostics. It is no longer a gate for OA activation.
    _ = nearest_obstacle_distance
    _ = active_distance
    _ = current_state

    reference_positions = reference_positions_from_state_horizon(reference_state)
    nominal_points = np.asarray(nominal_positions, dtype=float).reshape((-1, 2))

    for obstacle in obstacles:
        nominal_point_collision = trajectory_intersects_inflated_obstacle(nominal_points, obstacle, gamma)
        nominal_segment_collision = segments_intersect_inflated_obstacle(nominal_points, obstacle, gamma)
        reference_point_collision = trajectory_intersects_inflated_obstacle(reference_positions, obstacle, gamma)
        reference_segment_collision = segments_intersect_inflated_obstacle(reference_positions, obstacle, gamma)
        obstacle_copy = dict(obstacle)
        obstacle_copy["active"] = bool(
            nominal_point_collision
            or nominal_segment_collision
            or reference_point_collision
            or reference_segment_collision
        )
        obstacle_copy["relevance_debug"] = {
            "nominal_points": bool(nominal_point_collision),
            "nominal_segments": bool(nominal_segment_collision),
            "reference_points": bool(reference_point_collision),
            "reference_segments": bool(reference_segment_collision),
            "lidar_gate_used": False,
        }
        if obstacle_copy["active"]:
            active_obstacles.append(obstacle_copy)

    return active_obstacles


# Convert obstacle edges into log rows for obstacle_hulls.csv.
def obstacle_edges_to_rows(
    obstacles: list[dict[str, Any]],
    active_obstacle_ids: set[int],
    time_value: float,
    reference_index: int,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for obstacle in obstacles:
        vertices = np.asarray(obstacle["vertices"], dtype=float)
        halfspace_matrix = np.asarray(obstacle["G"], dtype=float)
        halfspace_vector = np.asarray(obstacle["f"], dtype=float)
        obstacle_id = int(obstacle["obstacle_id"])
        active = int(obstacle_id in active_obstacle_ids)
        for edge_id in range(len(vertices)):
            first_point = vertices[edge_id]
            second_point = vertices[(edge_id + 1) % len(vertices)]
            rows.append(
                {
                    "time": float(time_value),
                    "reference_index": int(reference_index),
                    "obstacle_id": obstacle_id,
                    "edge_id": int(edge_id),
                    "x1": float(first_point[0]),
                    "y1": float(first_point[1]),
                    "x2": float(second_point[0]),
                    "y2": float(second_point[1]),
                    "g1": float(halfspace_matrix[edge_id, 0]),
                    "g2": float(halfspace_matrix[edge_id, 1]),
                    "f": float(halfspace_vector[edge_id]),
                    "active": active,
                }
            )
    return rows
