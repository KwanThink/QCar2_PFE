"""Polyline Frenet-frame helpers for the QCar2 OAMPC Frenet controller."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import numpy as np


GEOMETRY_EPSILON = 1.0e-9


# Store the result of projecting one Cartesian point onto the reference path.
@dataclass
class FrenetProjection:
    s: float
    l: float
    segment_index: int
    ratio: float
    theta: float
    closest_point: np.ndarray
    tangent: np.ndarray
    normal: np.ndarray


# Return the signed area of a polygon represented by ordered vertices.
def polygon_signed_area(vertices: np.ndarray) -> float:
    vertex_array = np.asarray(vertices, dtype=float).reshape((-1, 2))
    x_coordinates = vertex_array[:, 0]
    y_coordinates = vertex_array[:, 1]
    return float(0.5 * np.sum(x_coordinates * np.roll(y_coordinates, -1) - y_coordinates * np.roll(x_coordinates, -1)))


# Return a convex hull using the monotonic-chain algorithm.
def convex_hull(points: np.ndarray) -> np.ndarray:
    point_array = np.asarray(points, dtype=float).reshape((-1, 2))
    if len(point_array) <= 1:
        return point_array.copy()
    ordered_points = sorted({(float(point[0]), float(point[1])) for point in point_array})
    if len(ordered_points) <= 1:
        return np.asarray(ordered_points, dtype=float)

    def cross_product(origin: tuple[float, float], first: tuple[float, float], second: tuple[float, float]) -> float:
        return (first[0] - origin[0]) * (second[1] - origin[1]) - (first[1] - origin[1]) * (second[0] - origin[0])

    lower: list[tuple[float, float]] = []
    for point in ordered_points:
        while len(lower) >= 2 and cross_product(lower[-2], lower[-1], point) <= 0.0:
            lower.pop()
        lower.append(point)

    upper: list[tuple[float, float]] = []
    for point in reversed(ordered_points):
        while len(upper) >= 2 and cross_product(upper[-2], upper[-1], point) <= 0.0:
            upper.pop()
        upper.append(point)

    hull = np.asarray(lower[:-1] + upper[:-1], dtype=float)
    if len(hull) >= 3 and polygon_signed_area(hull) < 0.0:
        hull = hull[::-1].copy()
    return hull


# Build and query a piecewise-linear reference path in Frenet coordinates.
class FrenetPath:
    # Initialize path samples, segment lengths, and cumulative arc length.
    def __init__(self, xy_points: np.ndarray):
        raw_points = np.asarray(xy_points, dtype=float).reshape((-1, 2))
        if len(raw_points) < 2:
            raise ValueError("FrenetPath requires at least two reference points.")

        filtered_points = [raw_points[0]]
        for point in raw_points[1:]:
            if float(np.linalg.norm(point - filtered_points[-1])) > GEOMETRY_EPSILON:
                filtered_points.append(point)
        if len(filtered_points) < 2:
            raise ValueError("FrenetPath reference points must span a nonzero distance.")

        self.points = np.asarray(filtered_points, dtype=float)
        self.segment_vectors = np.diff(self.points, axis=0)
        self.segment_lengths = np.linalg.norm(self.segment_vectors, axis=1)
        self.segment_tangents = self.segment_vectors / self.segment_lengths[:, None]
        self.cumulative_s = np.concatenate(([0.0], np.cumsum(self.segment_lengths)))
        self.total_length = float(self.cumulative_s[-1])

    # Return the left normal associated with a unit tangent vector.
    def normal_from_tangent(self, tangent: np.ndarray) -> np.ndarray:
        tangent_array = np.asarray(tangent, dtype=float).reshape(2)
        return np.array([-tangent_array[1], tangent_array[0]], dtype=float)

    # Project one Cartesian point onto the polyline and return its Frenet coordinates.
    def project_xy(self, xy_point: np.ndarray, start_segment: int | None = None, stop_segment: int | None = None) -> FrenetProjection:
        point = np.asarray(xy_point, dtype=float).reshape(2)
        first_segment = 0 if start_segment is None else max(0, int(start_segment))
        last_segment = len(self.segment_lengths) if stop_segment is None else min(len(self.segment_lengths), int(stop_segment))
        if first_segment >= last_segment:
            first_segment = 0
            last_segment = len(self.segment_lengths)

        best_distance_squared = float("inf")
        best_segment = first_segment
        best_ratio = 0.0
        best_closest = self.points[first_segment].copy()

        for segment_index in range(first_segment, last_segment):
            start = self.points[segment_index]
            tangent = self.segment_tangents[segment_index]
            length = float(self.segment_lengths[segment_index])
            ratio = float(np.clip(np.dot(point - start, tangent) / length, 0.0, 1.0))
            closest = start + ratio * length * tangent
            distance_squared = float(np.dot(point - closest, point - closest))
            if distance_squared < best_distance_squared:
                best_distance_squared = distance_squared
                best_segment = segment_index
                best_ratio = ratio
                best_closest = closest

        tangent = self.segment_tangents[best_segment]
        normal = self.normal_from_tangent(tangent)
        s_value = float(self.cumulative_s[best_segment] + best_ratio * self.segment_lengths[best_segment])
        l_value = float(np.dot(point - best_closest, normal))
        theta = math.atan2(float(tangent[1]), float(tangent[0]))
        return FrenetProjection(
            s=s_value,
            l=l_value,
            segment_index=int(best_segment),
            ratio=float(best_ratio),
            theta=float(theta),
            closest_point=best_closest,
            tangent=tangent.copy(),
            normal=normal.copy(),
        )

    # Return path tangent, normal, and heading angle at a scalar arc-length value.
    def frame_at_s(self, s_value: float) -> tuple[np.ndarray, np.ndarray, float]:
        clipped_s = float(np.clip(s_value, 0.0, self.total_length))
        segment_index = int(np.searchsorted(self.cumulative_s, clipped_s, side="right") - 1)
        segment_index = int(np.clip(segment_index, 0, len(self.segment_lengths) - 1))
        tangent = self.segment_tangents[segment_index]
        normal = self.normal_from_tangent(tangent)
        theta = math.atan2(float(tangent[1]), float(tangent[0]))
        return tangent.copy(), normal, float(theta)

    # Convert one Frenet position back into a Cartesian point.
    def frenet_to_xy(self, s_value: float, l_value: float) -> np.ndarray:
        clipped_s = float(np.clip(s_value, 0.0, self.total_length))
        segment_index = int(np.searchsorted(self.cumulative_s, clipped_s, side="right") - 1)
        segment_index = int(np.clip(segment_index, 0, len(self.segment_lengths) - 1))
        local_s = clipped_s - float(self.cumulative_s[segment_index])
        tangent = self.segment_tangents[segment_index]
        normal = self.normal_from_tangent(tangent)
        base_point = self.points[segment_index] + local_s * tangent
        return base_point + float(l_value) * normal

    # Convert a physical state [X, Y, psi, vx] to z = [s, s_dot, l, l_dot].
    def global_state_to_frenet_state(self, state: np.ndarray) -> np.ndarray:
        state_array = np.asarray(state, dtype=float).reshape(4)
        projection = self.project_xy(state_array[:2])
        yaw_error = float(state_array[2] - projection.theta)
        velocity = float(state_array[3])
        s_dot = velocity * math.cos(yaw_error)
        l_dot = velocity * math.sin(yaw_error)
        return np.array([projection.s, s_dot, projection.l, l_dot], dtype=float)

    # Convert a Cartesian reference horizon into a Frenet reference horizon.
    def global_horizon_to_frenet(self, reference_state: np.ndarray) -> np.ndarray:
        reference_array = np.asarray(reference_state, dtype=float).reshape((4, -1))
        frenet_state = np.zeros_like(reference_array)
        last_s = -float("inf")
        for column in range(reference_array.shape[1]):
            projected_state = self.global_state_to_frenet_state(reference_array[:, column])
            if projected_state[0] < last_s:
                projected_state[0] = last_s
            last_s = float(projected_state[0])
            frenet_state[:, column] = projected_state
        return frenet_state

    # Convert Frenet accelerations [s_ddot, l_ddot] to a global acceleration vector.
    def frenet_acceleration_to_global(self, s_value: float, v1: float, v2: float) -> np.ndarray:
        tangent, normal, _theta = self.frame_at_s(s_value)
        return float(v1) * tangent + float(v2) * normal

    # Convert a list of Frenet positions into Cartesian positions.
    def frenet_positions_to_global(self, frenet_positions: np.ndarray) -> np.ndarray:
        positions = np.asarray(frenet_positions, dtype=float).reshape((-1, 2))
        global_points = [self.frenet_to_xy(point[0], point[1]) for point in positions]
        return np.asarray(global_points, dtype=float)


# Transform a global obstacle polygon to a convex polygon in Frenet coordinates.
def obstacle_to_frenet(obstacle: dict[str, Any], frenet_path: FrenetPath) -> dict[str, Any]:
    global_vertices = np.asarray(obstacle["vertices"], dtype=float).reshape((-1, 2))
    frenet_vertices = []
    for vertex in global_vertices:
        projection = frenet_path.project_xy(vertex)
        frenet_vertices.append([projection.s, projection.l])
    frenet_hull = convex_hull(np.asarray(frenet_vertices, dtype=float))
    if len(frenet_hull) < 3:
        frenet_hull = np.asarray(frenet_vertices, dtype=float)

    from src.obstacle import polygon_to_halfspaces

    halfspace_matrix, halfspace_vector = polygon_to_halfspaces(frenet_hull)
    transformed_obstacle = dict(obstacle)
    transformed_obstacle["global_vertices"] = global_vertices
    transformed_obstacle["frenet_vertices"] = frenet_hull
    transformed_obstacle["vertices"] = frenet_hull
    transformed_obstacle["G"] = halfspace_matrix
    transformed_obstacle["f"] = halfspace_vector
    transformed_obstacle["number_of_edges"] = int(len(halfspace_vector))
    transformed_obstacle["coordinate_frame"] = "frenet"
    return transformed_obstacle


# Transform a list of global obstacle polygons into Frenet obstacle polygons.
def obstacles_to_frenet(obstacles: list[dict[str, Any]], frenet_path: FrenetPath) -> list[dict[str, Any]]:
    return [obstacle_to_frenet(obstacle, frenet_path) for obstacle in obstacles]
