"""Gurobi flat-coordinate MIQP OAMPC solver for QCar2 Mk2 tracking."""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import gurobipy as gp
from gurobipy import GRB

from src.oampc_solver_generator import OAMPCTemplate, build_oampc_template


# Store the first optimal physical input, virtual input, and solver diagnostics.
@dataclass
class SolverResult:
    delta: float
    ax: float
    v1: float
    v2: float
    status: str
    success: bool
    solve_time: float
    slack_value: float = 0.0
    mip_gap: float = 0.0
    number_of_candidate_obstacles: int = 0
    number_of_active_obstacles: int = 0
    number_of_active_edges: int = 0
    active_obstacles: list[Any] = field(default_factory=list)


# Clip a scalar value to a closed interval.
def clip(value: float, lower: float, upper: float) -> float:
    return float(np.clip(value, lower, upper))


# Wrap an angle to the interval [-pi, pi].
def wrap_to_pi(angle: float) -> float:
    return float((float(angle) + math.pi) % (2.0 * math.pi) - math.pi)


# Return the signed shortest angular error angle - reference_angle.
def angle_error(angle: float, reference_angle: float) -> float:
    return wrap_to_pi(float(angle) - float(reference_angle))


# Shift an angle by multiples of 2*pi so it stays close to a reference.
def unwrap_to_reference(angle: float, reference_angle: float) -> float:
    unwrapped_angle = float(angle)
    reference = float(reference_angle)
    while unwrapped_angle - reference > math.pi:
        unwrapped_angle -= 2.0 * math.pi
    while unwrapped_angle - reference < -math.pi:
        unwrapped_angle += 2.0 * math.pi
    return unwrapped_angle


# Solve a flat-coordinate Cartesian OAMPC MIQP with a persistent Gurobi template.
class GurobiFlatCoordinateOAMPC:
    # Initialize dimensions, weights, bounds, and the reusable Gurobi model.
    def __init__(self, config: dict[str, Any]):
        self.config = config
        oampc_config = config["oampc"]
        obstacle_config = config.get("obstacle_avoidance", {})
        constraints = oampc_config["constraints"]

        self.wheelbase = float(oampc_config["wheelbase"])
        self.epsilon = float(oampc_config["epsilon"])
        self.sample_time = float(oampc_config["Ts"])
        self.horizon_steps = int(oampc_config["N"])
        self.nx = 4
        self.nv = 2

        self.q_x = float(oampc_config["Q"][0])
        self.q_y = float(oampc_config["Q"][1])
        self.r_v1 = float(oampc_config["R"][0])
        self.r_v2 = float(oampc_config["R"][1])

        self.delta_min = float(constraints["delta_min"])
        self.delta_max = float(constraints["delta_max"])
        self.ax_min = float(constraints["ax_min"])
        self.ax_max = float(constraints["ax_max"])

        self.obstacle_enabled = bool(obstacle_config.get("enabled", True))
        self.big_m = float(obstacle_config.get("M", 100.0))
        self.gamma = float(obstacle_config.get("gamma", 0.35))
        self.slack_weight = float(obstacle_config.get("slack_weight", 1.0e6))
        self.max_active_obstacles = int(obstacle_config.get("max_active_obstacles", 0))
        self.max_hull_edges_per_obstacle = int(obstacle_config.get("max_hull_edges_per_obstacle", 3))

        self.template: OAMPCTemplate = build_oampc_template(config)
        self.model = self.template.model
        self.flat_state = self.template.flat_state
        self.virtual_input = self.template.virtual_input
        self.slack = self.template.slack
        self.alpha = self.template.alpha
        self.beta = self.template.beta
        self.w_constraints = self.template.w_constraints
        self.obstacle_face_constraints = self.template.obstacle_face_constraints
        self.obstacle_sum_alpha_constraints = self.template.obstacle_sum_alpha_constraints
        self.obstacle_beta_sum_constraints = self.template.obstacle_beta_sum_constraints

    # Reset any optional warm-start information.
    def reset_warm_start(self) -> None:
        for variable in self.model.getVars():
            variable.Start = GRB.UNDEFINED

    # Convert a physical QCar2 state into the flat state z = [X, X_dot, Y, Y_dot].
    def _current_flat_state(self, current_state: np.ndarray) -> np.ndarray:
        current_x = float(current_state[0])
        current_y = float(current_state[1])
        current_yaw = float(current_state[2])
        current_velocity = float(current_state[3])
        return np.array(
            [
                current_x,
                current_velocity * math.cos(current_yaw),
                current_y,
                current_velocity * math.sin(current_yaw),
            ],
            dtype=float,
        )

    # Fix the initial flat state by setting identical lower and upper bounds.
    def _fix_initial_flat_state(self, z0: np.ndarray) -> None:
        for state_index in range(self.nx):
            variable = self.flat_state[0, state_index]
            variable.LB = float(z0[state_index])
            variable.UB = float(z0[state_index])

    # Build the quadratic objective for the current Cartesian reference horizon.
    def _build_objective(self, reference_state: np.ndarray) -> gp.QuadExpr:
        objective = gp.QuadExpr()
        for step in range(self.horizon_steps):
            x_reference = float(reference_state[0, step + 1])
            y_reference = float(reference_state[1, step + 1])
            x_error = self.flat_state[step + 1, 0] - x_reference
            y_error = self.flat_state[step + 1, 2] - y_reference
            v1 = self.virtual_input[step, 0]
            v2 = self.virtual_input[step, 1]
            objective += self.q_x * x_error * x_error
            objective += self.q_y * y_error * y_error
            objective += self.r_v1 * v1 * v1
            objective += self.r_v2 * v2 * v2
        objective += self.slack_weight * self.slack
        return objective

    # Update the flat-input constraint W from the current yaw and velocity.
    def _update_virtual_input_constraints(self, current_state: np.ndarray) -> tuple[float, float, float]:
        psi = float(current_state[2])
        vx = float(current_state[3])
        vx_eps = vx * vx + self.epsilon

        m11 = -self.wheelbase / vx_eps * math.sin(psi)
        m12 = self.wheelbase / vx_eps * math.cos(psi)
        m21 = math.cos(psi)
        m22 = math.sin(psi)

        for step in range(self.horizon_steps):
            v1 = self.virtual_input[step, 0]
            v2 = self.virtual_input[step, 1]
            for constraint_name in ("steering_lower", "steering_upper"):
                constraint = self.w_constraints[constraint_name][step]
                self.model.chgCoeff(constraint, v1, m11)
                self.model.chgCoeff(constraint, v2, m12)
            for constraint_name in ("acceleration_lower", "acceleration_upper"):
                constraint = self.w_constraints[constraint_name][step]
                self.model.chgCoeff(constraint, v1, m21)
                self.model.chgCoeff(constraint, v2, m22)

        return psi, vx, vx_eps

    # Convert the first optimal virtual input into physical steering and acceleration.
    def _virtual_to_physical_input(self, v1: float, v2: float, psi: float, vx_eps: float) -> tuple[float, float]:
        steering_argument = (self.wheelbase / vx_eps) * (-float(v1) * math.sin(psi) + float(v2) * math.cos(psi))
        delta = math.atan(steering_argument)
        ax = float(v1) * math.cos(psi) + float(v2) * math.sin(psi)
        delta = clip(delta, self.delta_min, self.delta_max)
        ax = clip(ax, self.ax_min, self.ax_max)
        return delta, ax

    # Return a stable text name for the most common Gurobi status codes.
    def _status_name(self, status_code: int) -> str:
        status_names = {
            GRB.LOADED: "LOADED",
            GRB.OPTIMAL: "OPTIMAL",
            GRB.INFEASIBLE: "INFEASIBLE",
            GRB.INF_OR_UNBD: "INF_OR_UNBD",
            GRB.UNBOUNDED: "UNBOUNDED",
            GRB.CUTOFF: "CUTOFF",
            GRB.ITERATION_LIMIT: "ITERATION_LIMIT",
            GRB.NODE_LIMIT: "NODE_LIMIT",
            GRB.TIME_LIMIT: "TIME_LIMIT",
            GRB.SOLUTION_LIMIT: "SOLUTION_LIMIT",
            GRB.INTERRUPTED: "INTERRUPTED",
            GRB.NUMERIC: "NUMERIC",
            GRB.SUBOPTIMAL: "SUBOPTIMAL",
            GRB.INPROGRESS: "INPROGRESS",
            GRB.USER_OBJ_LIMIT: "USER_OBJ_LIMIT",
        }
        return status_names.get(int(status_code), f"STATUS_{int(status_code)}")

    # Decide whether the Gurobi result contains an applicable first control action.
    def _solution_is_usable(self, status_code: int) -> bool:
        if int(status_code) == GRB.OPTIMAL:
            return True
        usable_suboptimal_statuses = {GRB.SUBOPTIMAL, GRB.TIME_LIMIT, GRB.INTERRUPTED, GRB.USER_OBJ_LIMIT}
        return int(status_code) in usable_suboptimal_statuses and int(self.model.SolCount) > 0

    # Extract the predicted Cartesian positions from the current solution.
    def _predicted_positions(self) -> np.ndarray:
        positions = np.zeros((self.horizon_steps, 2), dtype=float)
        for step in range(self.horizon_steps):
            positions[step, 0] = float(self.flat_state[step + 1, 0].X)
            positions[step, 1] = float(self.flat_state[step + 1, 2].X)
        return positions

    # Return True if one point is inside the obstacle inflated by a margin.
    def _point_inside_inflated_obstacle(self, point: np.ndarray, obstacle: Any, margin: float) -> bool:
        G = np.asarray(obstacle.G, dtype=float)
        f = np.asarray(obstacle.f, dtype=float)
        if G.size == 0 or f.size == 0:
            return False
        return bool(np.all(G @ np.asarray(point, dtype=float).reshape(2) <= f + float(margin) + 1.0e-9))

    # Return True if an obstacle is relevant to a predicted or reference horizon.
    def _obstacle_is_relevant(self, obstacle: Any, predicted_positions: np.ndarray, reference_state: np.ndarray) -> bool:
        for point in predicted_positions:
            if self._point_inside_inflated_obstacle(point, obstacle, self.gamma):
                return True

        reference_points = np.column_stack((reference_state[0, 1:], reference_state[1, 1:]))
        for point in reference_points:
            if self._point_inside_inflated_obstacle(point, obstacle, self.gamma):
                return True
        return False

    # Select the candidate obstacles that should be active in the MIQP.
    def _select_relevant_obstacles(self, candidate_obstacles: list[Any], predicted_positions: np.ndarray, reference_state: np.ndarray, already_active_ids: set[int] | None = None) -> list[Any]:
        if already_active_ids is None:
            already_active_ids = set()
        relevant: list[Any] = []
        for obstacle in candidate_obstacles:
            obstacle_id = int(getattr(obstacle, "obstacle_id", len(relevant)))
            if obstacle_id in already_active_ids:
                continue
            if self._obstacle_is_relevant(obstacle, predicted_positions, reference_state):
                relevant.append(obstacle)
        relevant.sort(key=lambda item: float(getattr(item, "distance", 0.0)))
        return relevant

    # Deactivate all obstacle slots and fix all alpha and beta variables to zero.
    def _deactivate_obstacle_constraints(self) -> None:
        for obstacle_index in range(self.max_active_obstacles):
            for edge_index in range(self.max_hull_edges_per_obstacle):
                for step in range(self.horizon_steps):
                    alpha_variable = self.alpha[obstacle_index, edge_index, step]
                    alpha_variable.LB = 0.0
                    alpha_variable.UB = 0.0
                    face_constraint = self.obstacle_face_constraints[obstacle_index][edge_index][step]
                    self.model.chgCoeff(face_constraint, self.flat_state[step + 1, 0], 0.0)
                    self.model.chgCoeff(face_constraint, self.flat_state[step + 1, 2], 0.0)
                    self.model.chgCoeff(face_constraint, self.slack, 0.0)
                    self.model.chgCoeff(face_constraint, alpha_variable, 0.0)
                    face_constraint.RHS = 0.0

                for step in range(max(0, self.horizon_steps - 1)):
                    beta_variable = self.beta[obstacle_index, edge_index, step]
                    beta_variable.LB = 0.0
                    beta_variable.UB = 0.0

            for step in range(self.horizon_steps):
                sum_constraint = self.obstacle_sum_alpha_constraints[obstacle_index][step]
                for edge_index in range(self.max_hull_edges_per_obstacle):
                    self.model.chgCoeff(sum_constraint, self.alpha[obstacle_index, edge_index, step], 0.0)
                sum_constraint.RHS = 0.0

            for step in range(max(0, self.horizon_steps - 1)):
                beta_sum_constraint = self.obstacle_beta_sum_constraints[obstacle_index][step]
                for edge_index in range(self.max_hull_edges_per_obstacle):
                    self.model.chgCoeff(beta_sum_constraint, self.beta[obstacle_index, edge_index, step], 0.0)
                beta_sum_constraint.RHS = 0.0

    # Update obstacle Big-M and beta constraints for the current active hulls.
    def _activate_obstacle_constraints(self, active_obstacles: list[Any]) -> None:
        self._deactivate_obstacle_constraints()
        for obstacle_slot, obstacle in enumerate(active_obstacles[: self.max_active_obstacles]):
            G = np.asarray(obstacle.G, dtype=float)
            f = np.asarray(obstacle.f, dtype=float)
            active_edge_count = min(len(f), self.max_hull_edges_per_obstacle)
            for edge_index in range(active_edge_count):
                g1 = float(G[edge_index, 0])
                g2 = float(G[edge_index, 1])
                rhs_value = self.big_m - float(f[edge_index]) - self.gamma
                for step in range(self.horizon_steps):
                    alpha_variable = self.alpha[obstacle_slot, edge_index, step]
                    alpha_variable.LB = 0.0
                    alpha_variable.UB = 1.0
                    face_constraint = self.obstacle_face_constraints[obstacle_slot][edge_index][step]
                    self.model.chgCoeff(face_constraint, self.flat_state[step + 1, 0], -g1)
                    self.model.chgCoeff(face_constraint, self.flat_state[step + 1, 2], -g2)
                    self.model.chgCoeff(face_constraint, self.slack, -1.0)
                    self.model.chgCoeff(face_constraint, alpha_variable, self.big_m)
                    face_constraint.RHS = rhs_value

            for step in range(self.horizon_steps):
                sum_constraint = self.obstacle_sum_alpha_constraints[obstacle_slot][step]
                for edge_index in range(active_edge_count):
                    self.model.chgCoeff(sum_constraint, self.alpha[obstacle_slot, edge_index, step], 1.0)
                sum_constraint.RHS = 1.0

            for step in range(max(0, self.horizon_steps - 1)):
                beta_sum_constraint = self.obstacle_beta_sum_constraints[obstacle_slot][step]
                for edge_index in range(active_edge_count):
                    beta_variable = self.beta[obstacle_slot, edge_index, step]
                    beta_variable.LB = 0.0
                    beta_variable.UB = 1.0
                    self.model.chgCoeff(beta_sum_constraint, beta_variable, 1.0)
                beta_sum_constraint.RHS = 1.0

    # Optimize the current template and return status information.
    def _optimize_current_model(self) -> tuple[str, bool, float]:
        start_time = time.perf_counter()
        self.model.optimize()
        solve_time = time.perf_counter() - start_time
        status_code = int(self.model.Status)
        status = self._status_name(status_code)
        success = self._solution_is_usable(status_code)
        return status, success, solve_time

    # Return the current MIP gap if Gurobi exposes it for the latest solve.
    def _current_mip_gap(self) -> float:
        try:
            gap = float(self.model.MIPGap)
            if np.isfinite(gap):
                return gap
        except Exception:
            pass
        return 0.0

    # Build a SolverResult from the current usable Gurobi solution.
    def _build_success_result(self, status: str, solve_time: float, psi: float, vx_eps: float, active_obstacles: list[Any], candidate_count: int) -> SolverResult:
        v1 = float(self.virtual_input[0, 0].X)
        v2 = float(self.virtual_input[0, 1].X)
        delta, ax = self._virtual_to_physical_input(v1, v2, psi, vx_eps)
        active_edges = int(sum(min(len(np.asarray(obstacle.f).reshape(-1)), self.max_hull_edges_per_obstacle) for obstacle in active_obstacles))
        return SolverResult(
            delta=delta,
            ax=ax,
            v1=v1,
            v2=v2,
            status=status,
            success=True,
            solve_time=float(solve_time),
            slack_value=float(self.slack.X) if self.slack.X is not None else 0.0,
            mip_gap=self._current_mip_gap(),
            number_of_candidate_obstacles=int(candidate_count),
            number_of_active_obstacles=int(len(active_obstacles)),
            number_of_active_edges=active_edges,
            active_obstacles=list(active_obstacles),
        )

    # Build a safe failure result that remains within physical acceleration limits.
    def _build_failure_result(self, status: str, solve_time: float, candidate_count: int, active_obstacles: list[Any]) -> SolverResult:
        active_edges = int(sum(min(len(np.asarray(obstacle.f).reshape(-1)), self.max_hull_edges_per_obstacle) for obstacle in active_obstacles))
        return SolverResult(
            delta=0.0,
            ax=clip(self.ax_min, self.ax_min, self.ax_max),
            v1=0.0,
            v2=0.0,
            status=status,
            success=False,
            solve_time=float(solve_time),
            slack_value=0.0,
            mip_gap=0.0,
            number_of_candidate_obstacles=int(candidate_count),
            number_of_active_obstacles=int(len(active_obstacles)),
            number_of_active_edges=active_edges,
            active_obstacles=list(active_obstacles),
        )

    # Solve the OAMPC problem and return the first optimal control input.
    def solve(
        self,
        current_state: np.ndarray,
        reference_state: np.ndarray,
        reference_input: np.ndarray | None = None,
        candidate_obstacles: list[Any] | None = None,
    ) -> SolverResult:
        current_state = np.asarray(current_state, dtype=float).reshape(self.nx)
        reference_state = np.asarray(reference_state, dtype=float).reshape((self.nx, self.horizon_steps + 1))
        candidates = list(candidate_obstacles or []) if self.obstacle_enabled else []
        candidate_count = len(candidates)

        z0 = self._current_flat_state(current_state)
        self._fix_initial_flat_state(z0)
        psi, _vx, vx_eps = self._update_virtual_input_constraints(current_state)
        self.model.setObjective(self._build_objective(reference_state), GRB.MINIMIZE)

        total_solve_time = 0.0
        active_obstacles: list[Any] = []

        try:
            self._activate_obstacle_constraints([])
            self.model.update()
            nominal_status, nominal_success, nominal_solve_time = self._optimize_current_model()
            total_solve_time += nominal_solve_time

            if not nominal_success:
                active_obstacles = candidates[: self.max_active_obstacles]
                if active_obstacles:
                    self._activate_obstacle_constraints(active_obstacles)
                    self.model.update()
                    miqp_status, miqp_success, miqp_solve_time = self._optimize_current_model()
                    total_solve_time += miqp_solve_time
                    if miqp_success:
                        return self._build_success_result(miqp_status, total_solve_time, psi, vx_eps, active_obstacles, candidate_count)
                    return self._build_failure_result(miqp_status, total_solve_time, candidate_count, active_obstacles)
                return self._build_failure_result(nominal_status, total_solve_time, candidate_count, active_obstacles)

            nominal_positions = self._predicted_positions()
            if not candidates or self.max_active_obstacles <= 0:
                return self._build_success_result(nominal_status, total_solve_time, psi, vx_eps, active_obstacles, candidate_count)

            relevant_obstacles = self._select_relevant_obstacles(candidates, nominal_positions, reference_state)
            if not relevant_obstacles:
                return self._build_success_result(nominal_status, total_solve_time, psi, vx_eps, active_obstacles, candidate_count)

            active_obstacles = relevant_obstacles[: self.max_active_obstacles]
            active_ids = {int(getattr(obstacle, "obstacle_id", index)) for index, obstacle in enumerate(active_obstacles)}

            while active_obstacles:
                self._activate_obstacle_constraints(active_obstacles)
                self.model.update()
                miqp_status, miqp_success, miqp_solve_time = self._optimize_current_model()
                total_solve_time += miqp_solve_time
                if not miqp_success:
                    return self._build_failure_result(miqp_status, total_solve_time, candidate_count, active_obstacles)

                predicted_positions = self._predicted_positions()
                if len(active_obstacles) >= self.max_active_obstacles:
                    return self._build_success_result(miqp_status, total_solve_time, psi, vx_eps, active_obstacles, candidate_count)

                new_relevant = self._select_relevant_obstacles(candidates, predicted_positions, reference_state, active_ids)
                if not new_relevant:
                    return self._build_success_result(miqp_status, total_solve_time, psi, vx_eps, active_obstacles, candidate_count)

                slot_count = self.max_active_obstacles - len(active_obstacles)
                for obstacle in new_relevant[:slot_count]:
                    active_obstacles.append(obstacle)
                    active_ids.add(int(getattr(obstacle, "obstacle_id", len(active_ids))))

            return self._build_success_result(nominal_status, total_solve_time, psi, vx_eps, active_obstacles, candidate_count)

        except Exception as exc:
            return self._build_failure_result(f"exception: {exc}", total_solve_time, candidate_count, active_obstacles)
