"""LiDAR point-cloud clustering and conservative obstacle hull generation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from src.lidar import LidarScan


EPS = 1.0e-9


# Store one convex obstacle polytope generated from a LiDAR cluster.
@dataclass
class ObstacleHull:
    obstacle_id: int
    hull_vertices: np.ndarray
    hull_edges: list[tuple[np.ndarray, np.ndarray]]
    G: np.ndarray
    f: np.ndarray
    distance: float
    number_of_active_edges: int


# Return the Euclidean norm of a vector.
def vector_norm(vector: np.ndarray) -> float:
    return float(np.linalg.norm(np.asarray(vector, dtype=float)))


# Return the signed 2D cross product of OA and OB.
def cross(origin: np.ndarray, point_a: np.ndarray, point_b: np.ndarray) -> float:
    return float((point_a[0] - origin[0]) * (point_b[1] - origin[1]) - (point_a[1] - origin[1]) * (point_b[0] - origin[0]))


# Split angularly ordered LiDAR points into clusters using point spacing.
def split_clusters(local_points: np.ndarray, global_points: np.ndarray, distance_threshold: float) -> list[tuple[np.ndarray, np.ndarray]]:
    if len(local_points) == 0:
        return []

    clusters: list[tuple[np.ndarray, np.ndarray]] = []
    start_index = 0
    for index in range(1, len(local_points)):
        gap = vector_norm(local_points[index] - local_points[index - 1])
        if gap > float(distance_threshold):
            clusters.append((local_points[start_index:index], global_points[start_index:index]))
            start_index = index
    clusters.append((local_points[start_index:], global_points[start_index:]))
    return clusters


# Compute the span length of a point cluster.
def cluster_span(points: np.ndarray) -> float:
    if len(points) < 2:
        return 0.0
    endpoint_span = vector_norm(points[-1] - points[0])
    bounding_span = vector_norm(np.max(points, axis=0) - np.min(points, axis=0))
    return max(endpoint_span, bounding_span)


# Return the perpendicular distance of a point to a line segment.
def point_to_segment_distance(point: np.ndarray, start: np.ndarray, finish: np.ndarray) -> float:
    segment = finish - start
    segment_length_squared = float(np.dot(segment, segment))
    if segment_length_squared <= EPS:
        return vector_norm(point - start)
    ratio = float(np.clip(np.dot(point - start, segment) / segment_length_squared, 0.0, 1.0))
    projection = start + ratio * segment
    return vector_norm(point - projection)


# Simplify an ordered polyline with the Ramer-Douglas-Peucker algorithm.
def simplify_polyline(points: np.ndarray, distance_threshold: float) -> np.ndarray:
    if len(points) <= 2 or float(distance_threshold) <= 0.0:
        return np.asarray(points, dtype=float)

    max_distance = -1.0
    split_index = -1
    for index in range(1, len(points) - 1):
        distance = point_to_segment_distance(points[index], points[0], points[-1])
        if distance > max_distance:
            max_distance = distance
            split_index = index

    if max_distance > float(distance_threshold) and split_index > 0:
        first_part = simplify_polyline(points[: split_index + 1], distance_threshold)
        second_part = simplify_polyline(points[split_index:], distance_threshold)
        return np.vstack((first_part[:-1], second_part))
    return np.vstack((points[0], points[-1]))


# Build a conservative augmented point set behind observed LiDAR surface points.
def augment_cluster_points(global_points: np.ndarray, lidar_origin_global: np.ndarray, obstacle_thickness: float) -> np.ndarray:
    augmented_points: list[np.ndarray] = []
    origin = np.asarray(lidar_origin_global, dtype=float).reshape(2)
    for point in np.asarray(global_points, dtype=float):
        ray = point - origin
        ray_norm = vector_norm(ray)
        if ray_norm <= EPS:
            continue
        direction = ray / ray_norm
        augmented_points.append(point)
        augmented_points.append(point + float(obstacle_thickness) * direction)
    if not augmented_points:
        return np.zeros((0, 2), dtype=float)
    return np.vstack(augmented_points)


# Compute a 2D convex hull with vertices ordered counter-clockwise.
def convex_hull(points: np.ndarray) -> np.ndarray:
    point_array = np.unique(np.asarray(points, dtype=float), axis=0)
    if len(point_array) < 3:
        return np.zeros((0, 2), dtype=float)

    sorted_points = point_array[np.lexsort((point_array[:, 1], point_array[:, 0]))]
    lower: list[np.ndarray] = []
    for point in sorted_points:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], point) <= EPS:
            lower.pop()
        lower.append(point)

    upper: list[np.ndarray] = []
    for point in reversed(sorted_points):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], point) <= EPS:
            upper.pop()
        upper.append(point)

    hull = np.vstack((lower[:-1], upper[:-1]))
    if polygon_area(hull) < EPS:
        return np.zeros((0, 2), dtype=float)
    return hull


# Return the signed area of a polygon.
def polygon_area(vertices: np.ndarray) -> float:
    if len(vertices) < 3:
        return 0.0
    x_values = vertices[:, 0]
    y_values = vertices[:, 1]
    return float(0.5 * np.sum(x_values * np.roll(y_values, -1) - y_values * np.roll(x_values, -1)))


# Build a conservative axis-aligned bounding box around a polygon.
def axis_aligned_bounding_box(vertices: np.ndarray) -> np.ndarray:
    lower = np.min(vertices, axis=0)
    upper = np.max(vertices, axis=0)
    return np.array(
        [
            [lower[0], lower[1]],
            [upper[0], lower[1]],
            [upper[0], upper[1]],
            [lower[0], upper[1]],
        ],
        dtype=float,
    )


# Limit the number of hull edges using a conservative bounding box when needed.
def limit_hull_edges(vertices: np.ndarray, max_edges: int) -> np.ndarray:
    if len(vertices) <= int(max_edges):
        return vertices
    return axis_aligned_bounding_box(vertices)


# Convert ordered convex hull vertices to G p <= f half-space form.
def hull_to_halfspaces(vertices: np.ndarray) -> tuple[np.ndarray, np.ndarray, list[tuple[np.ndarray, np.ndarray]]]:
    vertex_array = np.asarray(vertices, dtype=float)
    if len(vertex_array) < 3:
        return np.zeros((0, 2), dtype=float), np.zeros(0, dtype=float), []

    if polygon_area(vertex_array) < 0.0:
        vertex_array = vertex_array[::-1]

    centroid = np.mean(vertex_array, axis=0)
    g_rows: list[np.ndarray] = []
    f_values: list[float] = []
    edges: list[tuple[np.ndarray, np.ndarray]] = []

    for index in range(len(vertex_array)):
        start = vertex_array[index]
        finish = vertex_array[(index + 1) % len(vertex_array)]
        tangent = finish - start
        tangent_norm = vector_norm(tangent)
        if tangent_norm <= EPS:
            continue
        normal = np.array([tangent[1], -tangent[0]], dtype=float) / tangent_norm
        rhs = float(np.dot(normal, start))
        if float(np.dot(normal, centroid)) > rhs:
            normal = -normal
            rhs = -rhs
        g_rows.append(normal)
        f_values.append(rhs)
        edges.append((start.copy(), finish.copy()))

    if not g_rows:
        return np.zeros((0, 2), dtype=float), np.zeros(0, dtype=float), []
    return np.vstack(g_rows), np.asarray(f_values, dtype=float), edges


# Score candidate hulls so the nearest and most relevant ones are used first.
def hull_priority_score(hull: ObstacleHull) -> float:
    return float(hull.distance)


# Generate conservative convex hulls from a filtered LiDAR scan.
def generate_candidate_obstacles(lidar_scan: LidarScan, config: dict[str, Any]) -> list[ObstacleHull]:
    obstacle_config = config.get("obstacle_avoidance", {})
    if not bool(obstacle_config.get("enabled", True)):
        return []
    if not lidar_scan.status or len(lidar_scan.global_points) == 0:
        return []

    min_cluster_points = int(obstacle_config.get("min_cluster_points", 4))
    min_cluster_span = float(obstacle_config.get("min_cluster_span", 0.05))
    cluster_distance_threshold = float(obstacle_config.get("cluster_distance_threshold", 0.12))
    simplify_distance_threshold = float(obstacle_config.get("simplify_distance_threshold", 0.03))
    obstacle_thickness = float(obstacle_config.get("obstacle_thickness", 0.5))
    max_edges = int(obstacle_config.get("max_hull_edges_per_obstacle", 6))

    clusters = split_clusters(lidar_scan.local_points, lidar_scan.global_points, cluster_distance_threshold)
    candidate_hulls: list[ObstacleHull] = []

    for obstacle_id, (_local_cluster, global_cluster) in enumerate(clusters):
        if len(global_cluster) < min_cluster_points:
            continue
        if cluster_span(global_cluster) < min_cluster_span:
            continue

        simplified_global = simplify_polyline(global_cluster, simplify_distance_threshold)
        if len(simplified_global) < 2:
            continue

        augmented_points = augment_cluster_points(simplified_global, lidar_scan.lidar_origin_global, obstacle_thickness)
        hull_vertices = convex_hull(augmented_points)
        if len(hull_vertices) < 3:
            continue

        hull_vertices = limit_hull_edges(hull_vertices, max_edges)
        G, f, hull_edges = hull_to_halfspaces(hull_vertices)
        if len(hull_edges) < 3:
            continue

        distances = np.linalg.norm(global_cluster - lidar_scan.lidar_origin_global.reshape(1, 2), axis=1)
        hull = ObstacleHull(
            obstacle_id=len(candidate_hulls),
            hull_vertices=hull_vertices,
            hull_edges=hull_edges,
            G=G,
            f=f,
            distance=float(np.min(distances)) if len(distances) else 0.0,
            number_of_active_edges=int(len(hull_edges)),
        )
        candidate_hulls.append(hull)

    candidate_hulls.sort(key=hull_priority_score)
    return candidate_hulls
