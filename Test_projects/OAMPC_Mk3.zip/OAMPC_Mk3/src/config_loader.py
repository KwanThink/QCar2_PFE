"""Configuration loading utilities for the Mk2 QLabs OAMPC project."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


REQUIRED_SECTIONS = ("project", "paths", "trajectory", "oampc", "obstacle_avoidance", "tracking", "qlabs", "visualization")
SUPPORTED_OBSTACLE_TYPES = {"cube", "cone", "cylinder", "sphere"}


# Return the absolute root folder of this project.
def project_root() -> Path:
    return Path(__file__).resolve().parents[1]


# Resolve a configured path relative to the project root when needed.
def resolve_project_path(root: Path, raw_path: str) -> Path:
    path = Path(raw_path).expanduser()
    if path.is_absolute():
        return path
    return (root / path).resolve()


# Validate that the loaded YAML file has the mandatory top-level sections.
def validate_required_sections(config: dict[str, Any]) -> None:
    missing_sections = [section for section in REQUIRED_SECTIONS if section not in config]
    if missing_sections:
        joined_sections = ", ".join(missing_sections)
        raise ValueError(f"Missing config section: {joined_sections}")


# Return the configured OAMPC constraints dictionary.
def oampc_constraints(config: dict[str, Any]) -> dict[str, Any]:
    return config["oampc"]["constraints"]


# Validate one configured QLabs obstacle spawn entry.
def validate_obstacle_spawn_entry(obstacle: dict[str, Any], index: int) -> None:
    required_keys = ("loc", "rot", "scale", "color", "type")
    for key in required_keys:
        if key not in obstacle:
            raise ValueError(f"obstacle_avoidance.obstacles[{index}] is missing '{key}'.")
    for key in ("loc", "rot", "scale", "color"):
        if len(obstacle[key]) != 3:
            raise ValueError(f"obstacle_avoidance.obstacles[{index}].{key} must contain three values.")
    if str(obstacle["type"]).lower() not in SUPPORTED_OBSTACLE_TYPES:
        print(f"Warning: obstacle type '{obstacle['type']}' is unsupported and will be spawned as cube.")


# Validate the obstacle avoidance section without using spawn geometry for constraints.
def validate_obstacle_avoidance(config: dict[str, Any]) -> None:
    obstacle_config = config["obstacle_avoidance"]
    required_scalars = (
        "lidar_fov",
        "M",
        "gamma",
        "slack_weight",
        "max_active_obstacles",
        "max_hull_edges_per_obstacle",
        "min_cluster_points",
        "min_cluster_span",
        "cluster_distance_threshold",
        "simplify_distance_threshold",
        "obstacle_thickness",
    )
    for key in required_scalars:
        if key not in obstacle_config:
            raise ValueError(f"Missing obstacle_avoidance.{key}.")

    if float(obstacle_config["lidar_fov"]) <= 0.0 or float(obstacle_config["lidar_fov"]) > 360.0:
        raise ValueError("obstacle_avoidance.lidar_fov must be in (0, 360].")
    if float(obstacle_config["M"]) <= 0.0:
        raise ValueError("obstacle_avoidance.M must be positive.")
    if float(obstacle_config["gamma"]) < 0.0:
        raise ValueError("obstacle_avoidance.gamma must be non-negative.")
    if float(obstacle_config["slack_weight"]) <= 0.0:
        raise ValueError("obstacle_avoidance.slack_weight must be positive.")
    if int(obstacle_config["max_active_obstacles"]) < 0:
        raise ValueError("obstacle_avoidance.max_active_obstacles must be non-negative.")
    if int(obstacle_config["max_hull_edges_per_obstacle"]) < 3:
        raise ValueError("obstacle_avoidance.max_hull_edges_per_obstacle must be at least 3.")
    if int(obstacle_config["min_cluster_points"]) < 2:
        raise ValueError("obstacle_avoidance.min_cluster_points must be at least 2.")
    if float(obstacle_config["obstacle_thickness"]) <= 0.0:
        raise ValueError("obstacle_avoidance.obstacle_thickness must be positive.")

    for index, obstacle in enumerate(obstacle_config.get("obstacles", []) or []):
        validate_obstacle_spawn_entry(obstacle, index)


# Validate the most important scalar and array values used by the project.
def validate_config_values(config: dict[str, Any]) -> None:
    waypoints = config["trajectory"]["waypoints"]
    segment_times = config["trajectory"]["segment_times"]
    oampc_config = config["oampc"]
    constraints = oampc_constraints(config)

    if len(waypoints) < 2:
        raise ValueError("trajectory.waypoints must contain at least two points.")
    if len(segment_times) != len(waypoints) - 1:
        raise ValueError("trajectory.segment_times must have one value per segment.")
    if int(oampc_config["N"]) <= 0:
        raise ValueError("Prediction horizon 'N' must be positive.")
    if float(oampc_config["Ts"]) <= 0.0:
        raise ValueError("Sampling time 'Ts' must be positive.")
    if float(oampc_config["wheelbase"]) <= 0.0:
        raise ValueError("oampc.wheelbase must be positive.")
    if float(oampc_config["epsilon"]) <= 0.0:
        raise ValueError("oampc.epsilon must be positive.")
    if len(oampc_config["Q"]) != 2:
        raise ValueError("oampc.Q must contain [Q_x, Q_y].")
    if len(oampc_config["R"]) != 2:
        raise ValueError("oampc.R must contain [R_v1, R_v2].")
    if float(constraints["delta_min"]) >= float(constraints["delta_max"]):
        raise ValueError("oampc.constraints.delta_min must be smaller than delta_max.")
    if float(constraints["ax_min"]) >= float(constraints["ax_max"]):
        raise ValueError("oampc.constraints.ax_min must be smaller than ax_max.")
    if float(constraints.get("vx_min", -1.0)) >= float(constraints.get("vx_max", 1.0)):
        raise ValueError("oampc.constraints.vx_min must be smaller than vx_max.")

    validate_obstacle_avoidance(config)


# Load the YAML config and attach resolved project paths for internal use.
def load_config(config_path: str | Path | None = None) -> dict[str, Any]:
    root = project_root()
    path = Path(config_path).expanduser().resolve() if config_path is not None else root / "oampc_config_mk2.yaml"
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with path.open("r", encoding="utf-8") as file:
        config = yaml.safe_load(file) or {}

    validate_required_sections(config)
    validate_config_values(config)

    paths = config["paths"]
    config["_project_root"] = str(root)
    config["_config_path"] = str(path)
    config["_resolved_paths"] = {
        "quanser_python_dir": str(resolve_project_path(root, paths["quanser_python_dir"])),
        "generated_trajectory_dir": str(resolve_project_path(root, paths["generated_trajectory_dir"])),
        "results_dir": str(resolve_project_path(root, paths["results_dir"])),
        "generated_solver_dir": str(resolve_project_path(root, "generated_oampc_solver")),
    }
    return config
