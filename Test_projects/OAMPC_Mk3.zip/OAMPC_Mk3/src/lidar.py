"""QLabs LiDAR reading and point-cloud filtering for OAMPC Mk2."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import numpy as np


# Store a filtered LiDAR scan in local and global Cartesian coordinates.
@dataclass
class LidarScan:
    status: bool
    local_points: np.ndarray
    global_points: np.ndarray
    local_angles: np.ndarray
    distances: np.ndarray
    nearest_front_distance: float | None
    lidar_origin_global: np.ndarray


# Wrap angles to the interval [-pi, pi].
def wrap_to_pi(angles: np.ndarray) -> np.ndarray:
    return (np.asarray(angles, dtype=float) + math.pi) % (2.0 * math.pi) - math.pi


# Return an empty LiDAR scan with a valid origin for downstream code.
def empty_lidar_scan(current_state: np.ndarray, status: bool = False) -> LidarScan:
    origin = np.asarray(current_state[:2], dtype=float).reshape(2)
    return LidarScan(
        status=status,
        local_points=np.zeros((0, 2), dtype=float),
        global_points=np.zeros((0, 2), dtype=float),
        local_angles=np.zeros(0, dtype=float),
        distances=np.zeros(0, dtype=float),
        nearest_front_distance=None,
        lidar_origin_global=origin,
    )


# Convert local QCar-frame points into global Cartesian coordinates.
def local_to_global_points(local_points: np.ndarray, current_state: np.ndarray) -> np.ndarray:
    if local_points.size == 0:
        return np.zeros((0, 2), dtype=float)
    x_global = float(current_state[0])
    y_global = float(current_state[1])
    yaw = float(current_state[2])
    rotation = np.array(
        [
            [math.cos(yaw), -math.sin(yaw)],
            [math.sin(yaw), math.cos(yaw)],
        ],
        dtype=float,
    )
    return local_points @ rotation.T + np.array([x_global, y_global], dtype=float)


# Filter raw polar LiDAR data to the front FOV and convert it to Cartesian points.
def filter_lidar_measurements(
    angles: np.ndarray,
    distances: np.ndarray,
    current_state: np.ndarray,
    lidar_fov_degrees: float,
    min_range: float = 0.2,
    max_range: float = 12.0,
) -> LidarScan:
    raw_angles = np.asarray(angles, dtype=float).reshape(-1)
    raw_distances = np.asarray(distances, dtype=float).reshape(-1)
    point_count = min(raw_angles.size, raw_distances.size)
    if point_count == 0:
        return empty_lidar_scan(current_state, status=False)

    raw_angles = raw_angles[:point_count]
    raw_distances = raw_distances[:point_count]
    local_angles = wrap_to_pi(raw_angles)
    half_fov = math.radians(float(lidar_fov_degrees)) * 0.5

    valid = np.isfinite(local_angles) & np.isfinite(raw_distances)
    valid &= raw_distances >= float(min_range)
    valid &= raw_distances <= float(max_range)
    valid &= np.abs(local_angles) <= half_fov

    if not np.any(valid):
        return empty_lidar_scan(current_state, status=True)

    filtered_angles = local_angles[valid]
    filtered_distances = raw_distances[valid]
    order = np.argsort(filtered_angles)
    filtered_angles = filtered_angles[order]
    filtered_distances = filtered_distances[order]

    x_local = filtered_distances * np.cos(filtered_angles)
    y_local = filtered_distances * np.sin(filtered_angles)
    local_points = np.column_stack((x_local, y_local))

    front_mask = local_points[:, 0] > 0.0
    local_points = local_points[front_mask]
    filtered_angles = filtered_angles[front_mask]
    filtered_distances = filtered_distances[front_mask]
    if local_points.size == 0:
        return empty_lidar_scan(current_state, status=True)

    global_points = local_to_global_points(local_points, current_state)
    nearest_front_distance = float(np.min(filtered_distances)) if filtered_distances.size else None
    return LidarScan(
        status=True,
        local_points=local_points,
        global_points=global_points,
        local_angles=filtered_angles,
        distances=filtered_distances,
        nearest_front_distance=nearest_front_distance,
        lidar_origin_global=np.asarray(current_state[:2], dtype=float).reshape(2),
    )


# Read QLabs QCar2 LiDAR and return filtered local and global point clouds.
def read_lidar_scan(qcar2: Any, current_state: np.ndarray, config: dict[str, Any]) -> LidarScan:
    obstacle_config = config.get("obstacle_avoidance", {})
    lidar_fov = float(obstacle_config.get("lidar_fov", 100.0))
    try:
        status, angles, distances = qcar2.get_lidar(samplePoints=720)
    except Exception:
        return empty_lidar_scan(current_state, status=False)

    if not status or angles is None or distances is None:
        return empty_lidar_scan(current_state, status=False)

    return filter_lidar_measurements(
        angles=np.asarray(angles, dtype=float),
        distances=np.asarray(distances, dtype=float),
        current_state=np.asarray(current_state, dtype=float),
        lidar_fov_degrees=lidar_fov,
        min_range=0.2,
        max_range=12.0,
    )
